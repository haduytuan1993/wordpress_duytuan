<?php
/* add_ons_php */
?>
<div class="dashboard-content-wrapper dashboard-content-chat">
    <div class="dashboard-list-box fl-wrap">
        <div id="chat-app-backend"></div>
    </div>
</div>